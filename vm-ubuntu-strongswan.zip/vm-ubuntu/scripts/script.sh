#!/bin/sh
sudo apt-get update
sudo apt install moreutils -y

# == To run this script
# wget https://asmprdsamgt1.blob.core.windows.net/deployment//setup.sh
# chmod u+x setup.sh
# ./setup.sh

echo
echo "--- Configuration: general server settings ---"
echo

#VPNHOST=$0
VPNHOST=vmp1wss1
DNS=vmp1wss1
CN=asmvmp1wss1.northeurope.cloudapp.azure.com

VPNHOSTIP=$(dig -4 +short "$VPNHOST")
VPNHOSTPIP=$(dig +short myip.opendns.com @resolver1.opendns.com)
VPNIPPOOL="10.10.10.0/24"
ETH0ORSIMILAR=$(ip route get 8.8.8.8 | awk -- '{printf $5}')
IP=$(ifdata -pa $ETH0ORSIMILAR)

echo
echo "Network interface: ${ETH0ORSIMILAR}"
echo "External IP: ${IP}"

echo
echo "--- Updating and installing software ---"
echo

# 1 Install strongSwan

sudo apt-get install strongswan strongswan-pki libcharon-extra-plugins -y
sudo apt-get upgrade 

cd ~
sudo mkdir -p pki/private
sudo mkdir -p pki/certs
sudo mkdir -p pki/cacerts
#chmod 700 pki

# 2 Create CA
# create root key
sudo ipsec pki --gen --type rsa --size 4096 --outform pem > ~/pki/private/ca-key.pem
# create root CA
sudo ipsec pki --self --ca --lifetime 3650 --in ~/pki/private/ca-key.pem --type rsa --dn "CN=VPN root CA" --outform pem > ~/pki/cacerts/ca-cert.pem
# create server key
sudo ipsec pki --gen --type rsa --size 4096 --outform pem > ~/pki/private/server-key.pem

# 3 Create certificate for VPN server
sudo ipsec pki --pub --in ~/pki/private/server-key.pem --type rsa \
    | ipsec pki --issue --lifetime 1825 \
        --cacert ~/pki/cacerts/ca-cert.pem \
        --cakey ~/pki/private/ca-key.pem \
        --dn "CN=${CN}" --san "${IP}" \
        --flag serverAuth --flag ikeIntermediate --outform pem \
    >  ~/pki/certs/server-cert.pem

# copy all certs 
sudo cp -r ~/pki/* /etc/ipsec.d/

# 4 Configure strongSwan
# iOS/Mac with appropriate configuration profiles use AES_GCM_16_256/PRF_HMAC_SHA2_256/ECP_521 
# Windows 10 uses AES_CBC_256/HMAC_SHA2_256_128/PRF_HMAC_SHA2_256/ECP_384 
# Windows: Set-ItemProperty -Path HKLM:\System\CurrentControlSet\Services\Rasman\Parameters -Name NegotiateDH2048_AES256 -Type DWord -Value 1 -Force
sudo mv /etc/ipsec.conf /etc/ipsec.conf.original
echo "config setup
  strictcrlpolicy=yes
  uniqueids=never
conn roadwarrior
  auto=add
  compress=no
  type=tunnel
  keyexchange=ikev2
  fragmentation=yes
  forceencaps=yes
  ike=aes256gcm16-sha256-ecp521,aes256-sha256-ecp384!
  esp=aes256gcm16-sha256,aes256gcm16-ecp384!
  dpdaction=clear
  dpddelay=300s
  rekey=no
  left=%any
  leftid=@${VPNHOSTIP}
  leftcert=server-cert.pem
  leftsendcert=always
  leftsubnet=172.18.0.0/16 
  right=%any
  rightid=%any
  rightauth=eap-mschapv2
  eap_identity=%any
  rightdns=8.8.8.8,8.8.4.4
  rightsourceip=${VPNIPPOOL}
  rightsendcert=never
" > /etc/ipsec.conf

sudo mv /etc/ipsec.secrets /etc/ipsec.secrets.original
echo ': RSA "server-key.pem"
user1 : EAP "password1"
user2 : EAP "password2"
' > /etc/ipsec.secrets

sudo systemctl restart strongswan

echo
echo "--- Configuring firewall ---"
echo

# Enabled UFW and add firewall rules
sudo ufw allow OpenSSH
sudo ufw enable
sudo ufw allow 500,4500/udp
sudo ufw allow 1701/udp
sudo ufw allow to "$VPNHOSTIP" proto esp
sudo ufw allow to "$VPNHOSTIP" from 0.0.0.0/0 proto esp
sudo ufw allow to "$VPNHOSTIP" proto ah
sudo ufw allow to "$VPNHOSTIP" from 0.0.0.0/0 proto ah
sudo ufw disable
sudo ufw enable

sudo ufw status
ip route | grep default

# Need to put the CA cert on the client machine(s) (Computer Account on Windows, in Trusted Root Certification Authorities). Save as ca-cert.pem
cat /etc/ipsec.d/cacerts/ca-cert.pem

